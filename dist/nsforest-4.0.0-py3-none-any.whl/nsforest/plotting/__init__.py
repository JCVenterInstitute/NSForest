
from ._make_plots import boxplot, scatter_w_clusterSize, dotplot, stackedviolin, matrixplot

__all__ = ["boxplot", "scatter_w_clusterSize", "dotplot", "stackedviolin", "matrixplot", ]
